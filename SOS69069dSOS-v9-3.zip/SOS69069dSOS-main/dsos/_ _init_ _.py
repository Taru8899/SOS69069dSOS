"""dSOS read-only toolkit."""
